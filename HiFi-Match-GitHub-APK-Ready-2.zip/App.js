
import React from "react";
import { NavigationContainer, DarkTheme } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { StatusBar } from "expo-status-bar";
import HomeScreen from "./src/screens/HomeScreen";
import SystemsScreen from "./src/screens/SystemsScreen";
import FirstSystemScreen from "./src/screens/FirstSystemScreen";
import DatabaseScreen from "./src/screens/DatabaseScreen";
import SystemDetailsScreen from "./src/screens/SystemDetailsScreen";
import { colors } from "./src/theme";
import { AppDataProvider } from "./src/context/AppDataContext";
import ProfileScreen from "./src/screens/ProfileScreen";
import AddSystemScreen from "./src/screens/AddSystemScreen";
import AuthScreen from "./src/screens/AuthScreen";
import { AuthProvider } from "./src/context/AuthContext";
import { SubscriptionProvider } from "./src/context/SubscriptionContext";
import PremiumScreen from "./src/screens/PremiumScreen";
import MatchLabScreen from "./src/screens/MatchLabScreen";
import AboutScreen from "./src/screens/AboutScreen";

const Stack = createNativeStackNavigator();

const navTheme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: colors.bg,
    card: colors.bg,
    border: colors.border,
    text: colors.text,
    primary: colors.gold
  }
};

export default function App() {
  return (
    <AuthProvider>
      <SubscriptionProvider>
      <AppDataProvider>
      <NavigationContainer theme={navTheme}>
      <StatusBar style="light" />
      <Stack.Navigator
        screenOptions={{
          headerStyle: { backgroundColor: colors.bg },
          headerTintColor: colors.text,
          contentStyle: { backgroundColor: colors.bg }
        }}
      >
        <Stack.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
        <Stack.Screen name="Systems" component={SystemsScreen} options={{ title: "Mine anlegg" }} />
        <Stack.Screen name="FirstSystem" component={FirstSystemScreen} options={{ title: "Mitt første HiFi-anlegg" }} />
        <Stack.Screen name="Database" component={DatabaseScreen} options={{ title: "HiFi-database" }} />
        <Stack.Screen name="SystemDetails" component={SystemDetailsScreen} options={{ title: "Anleggsdetaljer" }} />
        <Stack.Screen name="Profile" component={ProfileScreen} options={{ title: "Min profil" }} />
        <Stack.Screen name="AddSystem" component={AddSystemScreen} options={{ title: "Legg til anlegg" }} />
        <Stack.Screen name="Auth" component={AuthScreen} options={{ title: "Konto" }} />
        <Stack.Screen name="Premium" component={PremiumScreen} options={{ title: "HiFi-Match Premium" }} />
        <Stack.Screen name="MatchLab" component={MatchLabScreen} options={{ title: "Finn en match" }} />
        <Stack.Screen name="About" component={AboutScreen} options={{ title: "Om HiFi-Match" }} />
      </Stack.Navigator>
      </NavigationContainer>
      </AppDataProvider>
      </SubscriptionProvider>
    </AuthProvider>
  );
}
