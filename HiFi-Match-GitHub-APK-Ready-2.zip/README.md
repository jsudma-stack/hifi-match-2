# HiFi-Match mobile beta

Dette er første fungerende React Native / Expo-versjon av HiFi-Match.

## Inneholder
- Startside
- Førstegangsguide med 6 spørsmål
- Resultatskjerm
- Mine anlegg med 3 testanlegg
- Mørkt HiFi-Match-design

## Kjør lokalt
1. Installer Node.js
2. Installer Expo Go på telefonen
3. Åpne terminal i prosjektmappen
4. Kjør:
   npm install
   npm start
5. Skann QR-koden med Expo Go

## Neste utviklingssteg
- ekte produktdatabase
- innlogging
- lagring av brukerens anlegg
- matchmotor
- bruktmarked / priser
- abonnement og betaling
- app-ikoner, bilder og butikkpublisering

## Rettigheter
© 2026 Jørn Sudmann. Alle rettigheter forbeholdt.

## Versjon 0.2
- Søkbar lokal HiFi-database
- Første matchmotor-kjerne
- Detaljside for hvert anlegg
- Klikkbare anlegg fra Mine anlegg

## Versjon 0.3
- Lokal brukerprofil
- Persistent lagring med Async Storage
- Brukeren kan legge til egne anlegg
- Mine anlegg leses fra lagret brukerdata
- Rettighetsmerking beholdt

Merk: Denne versjonen har lokal profil, ikke ekte konto/serverinnlogging ennå.

## Versjon 0.4
- Supabase Auth-klargjøring for e-post/passord
- Vedvarende innloggingssesjon
- Miljøvariabler via EXPO_PUBLIC_*
- Sky-repository for brukerens anlegg
- SQL-skjema med Row Level Security
- Lokal modus fungerer fortsatt uten skyløsning

### Aktivere ekte beta-kontoer
1. Opprett et Supabase-prosjekt.
2. Kjør `supabase/schema.sql` i SQL Editor.
3. Kopier `.env.example` til `.env`.
4. Legg inn prosjektets URL og publishable key.
5. Kjør `npm install` og `npm start`.

Ikke legg service-role-nøkkel i mobilappen.

## Versjon 0.5 – Premium beta
- Gratis- og Premium-nivå
- Premium-skjerm og funksjonsliste
- Lokal Premium-teststatus (ingen faktisk betaling)
- Gratisbruker kan lagre ett eget anlegg
- Premium gir ubegrenset antall egne anlegg
- Betalingsplan for App Store og Google Play i `PAYMENTS.md`

Faktiske butikkjøp aktiveres først når utviklerkontoer og butikkprodukter er opprettet.

## Versjon 0.6 – Match Engine Beta
- Ny forklarbar matchmotor
- Teknisk kompatibilitet
- Lydkarakter
- Nivåmatching
- Forsterker/høyttaler-vurdering
- Pickup/RIAA-vurdering
- Detaljert delscore og forklaringer
- Demoanalyse av eierens tre testanlegg
- Egen dokumentasjon i `MATCH_ENGINE.md`

## Versjon 0.7 – Launch Readiness
- Appen er tydelig merket som Beta
- Om-skjerm med rettigheter og beta-informasjon
- Beta personvernerklæring
- Beta brukervilkår
- Beta launch checklist
- Foreløpig butikktekst
- Versjonsnummer/buildnummer oppdatert

Se `BETA_LAUNCH_CHECKLIST.md` for hva som gjenstår før eksterne testere og offentlig lansering.

## Versjon 0.8 – Product Data Verification
- Første produsentverifiserte produktdata
- Datastatus per produkt
- Datakonfidens i Match Lab
- Korrigert AZ-Two maks effekt til 120 W
- Dokumentert verifiseringsstatus i `docs/PRODUCT_DATA_VERIFICATION.md`

## Versjon 0.9 – Verification Round 2
- KEF XQ40 verifisert
- AW100 DMB verifisert
- Sonus Faber Toy Tower verifisert
- ECP 1 verifisert
- AT33E beholdt som uverifisert inntil modellspesifikk dokumentasjon er funnet

## Versjon 0.9.1 – AT33EV correction
- Korrigert Audio-Technica AT33E til AT33EV i hele prosjektet
- AT33EV er nå verifisert mot Audio-Technicas originale datablad
- Oppdatert Anlegg 2 og vinyl-matchkjeden
