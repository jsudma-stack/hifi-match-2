
function clamp(n, min=0, max=100) {
  return Math.max(min, Math.min(max, n));
}

function avg(values) {
  const clean = values.filter(v => Number.isFinite(v));
  return clean.length ? clean.reduce((a,b)=>a+b,0)/clean.length : 0;
}

function complementScore(a, b) {
  if (!a?.tone || !b?.tone) return { score: 70, reasons:["Lydprofil mangler for én av komponentene."] };

  // Slight tonal complement is rewarded; extremes paired with extremes are penalized.
  const dims = ["warmth","detail","dynamics","smoothness"];
  let scores = [];
  let reasons = [];

  for (const d of dims) {
    const av = a.tone[d] ?? 3;
    const bv = b.tone[d] ?? 3;
    const mean = (av+bv)/2;
    const gap = Math.abs(av-bv);

    let s = 100 - Math.abs(mean-4.0)*12 - Math.max(0, gap-1.7)*10;
    if (mean > 4.6 || mean < 2.5) s -= 8;
    scores.push(clamp(s));
  }

  if ((a.tone.warmth >= 4.1 && b.tone.detail >= 4.1) || (b.tone.warmth >= 4.1 && a.tone.detail >= 4.1)) {
    reasons.push("God balanse mellom varme og detaljering.");
  }
  if (Math.abs((a.tone.dynamics||3)-(b.tone.dynamics||3)) <= 0.8) {
    reasons.push("Dynamisk karakter passer godt sammen.");
  }
  return { score: Math.round(avg(scores)), reasons };
}

function levelScore(a,b) {
  const gap = Math.abs((a?.tier ?? 3) - (b?.tier ?? 3));
  const score = gap === 0 ? 100 : gap === 1 ? 92 : gap === 2 ? 78 : 62;
  const reasons = gap <= 1
    ? ["Komponentene ligger på et godt matchende kvalitetsnivå."]
    : ["Det er et tydelig nivåsprang mellom komponentene."];
  return { score, reasons };
}

function ampSpeakerScore(amp, speaker) {
  if (!amp || !speaker) return null;
  const ampTypes = ["integrated_amp","power_amp"];
  if (!ampTypes.includes(amp.type) || speaker.type !== "speaker") return null;

  let score = 100;
  let reasons = [];

  if (speaker.impedanceMin && speaker.impedanceMin < 3) {
    score -= 18;
    reasons.push("Høyttaleren har lav minimumsimpedans og krever en strømsterk forsterker.");
  } else if (speaker.impedanceMin && speaker.impedanceMin <= 4) {
    score -= 4;
    reasons.push("Forsterkeren bør ha god kontroll ved lavere impedans.");
  }

  const power = amp.power8 || amp.power4 || 0;
  if (speaker.recommendedPowerMin && power < speaker.recommendedPowerMin) {
    score -= 28;
    reasons.push("Forsterkeren kan være i svakeste laget i forhold til anbefalt effekt.");
  } else if (speaker.recommendedPowerMax && power > speaker.recommendedPowerMax*1.8) {
    score -= 7;
    reasons.push("Forsterkeren har mye effekt; volumkontroll og forsiktig bruk blir viktig.");
  } else if (power) {
    reasons.push("Effektnivået ser godt egnet ut til høyttaleren.");
  }

  if (speaker.sensitivity) {
    if (speaker.sensitivity >= 92) reasons.push("Høy følsomhet gjør høyttaleren relativt lettdrevet.");
    else if (speaker.sensitivity < 86) {
      score -= 8;
      reasons.push("Lav følsomhet øker kravet til forsterkerkraft.");
    }
  }

  return { score: clamp(Math.round(score)), reasons };
}

function cartridgePhonoScore(cart, phono) {
  if (!cart || !phono) return null;
  if (cart.type !== "cartridge" || phono.type !== "phono") return null;

  let score = 100;
  let reasons = [];

  if (cart.cartridgeType === "MC" && !phono.supportsMC) {
    score -= 60;
    reasons.push("MC-pickup krever et RIAA-trinn som støtter MC.");
  } else if (cart.cartridgeType === "MM" && !phono.supportsMM) {
    score -= 60;
    reasons.push("MM-pickup krever et RIAA-trinn som støtter MM.");
  } else {
    reasons.push(`RIAA-trinnet støtter ${cart.cartridgeType || "pickup-typen"}.`);
  }

  if (cart.outputMv && phono.gainDbMax) {
    const lowOutput = cart.outputMv < 0.8;
    if (lowOutput && phono.gainDbMax < 58) {
      score -= 20;
      reasons.push("Lav pickup-utgang kan kreve mer gain enn dette RIAA-trinnet tilbyr.");
    } else if (lowOutput) {
      reasons.push("Gain-området ser egnet ut for en lavnivå MC-pickup.");
    }
  }

  return { score: clamp(Math.round(score)), reasons };
}

function typeCompatibility(a,b) {
  const pairs = new Set([
    "preamp:power_amp",
    "dac:integrated_amp",
    "dac:preamp",
    "streamer:dac",
    "streamer:integrated_amp",
    "turntable:cartridge",
    "cartridge:phono",
    "phono:integrated_amp",
    "phono:preamp",
    "integrated_amp:speaker",
    "power_amp:speaker"
  ]);
  const key = `${a?.type}:${b?.type}`;
  if (pairs.has(key)) return {score:100,reasons:["Komponenttypene passer naturlig i samme signalkjede."]};
  return {score:82,reasons:["Ingen direkte teknisk konflikt registrert i denne beta-versjonen."]};
}

export function analyzePair(a,b) {
  const tonal = complementScore(a,b);
  const level = levelScore(a,b);
  const type = typeCompatibility(a,b);
  const ampSpeaker = ampSpeakerScore(a,b);
  const cartPhono = cartridgePhonoScore(a,b);

  const weighted = [
    {name:"Teknisk kompatibilitet", weight:0.35, value: type.score},
    {name:"Lydkarakter", weight:0.30, value: tonal.score},
    {name:"Nivåmatching", weight:0.20, value: level.score},
  ];

  if (ampSpeaker) weighted.push({name:"Forsterker / høyttaler", weight:0.15, value:ampSpeaker.score});
  else if (cartPhono) weighted.push({name:"Pickup / RIAA", weight:0.15, value:cartPhono.score});
  else weighted.push({name:"Kjede-egnethet", weight:0.15, value:90});

  const totalWeight = weighted.reduce((s,x)=>s+x.weight,0);
  const score = Math.round(weighted.reduce((s,x)=>s+x.value*x.weight,0)/totalWeight);

  const reasons = [
    ...type.reasons,
    ...tonal.reasons,
    ...level.reasons,
    ...(ampSpeaker?.reasons || []),
    ...(cartPhono?.reasons || [])
  ];

  return { score: clamp(score), breakdown: weighted, reasons: [...new Set(reasons)] };
}

export function analyzeSystem(products) {
  const pairs = [];
  for (let i=0;i<products.length-1;i++) {
    pairs.push({
      from:products[i],
      to:products[i+1],
      analysis:analyzePair(products[i],products[i+1])
    });
  }
  if (!pairs.length) return {score:0,pairs:[],summary:["Legg inn minst to komponenter."]};

  const score = Math.round(avg(pairs.map(p=>p.analysis.score)));
  const weakest = [...pairs].sort((a,b)=>a.analysis.score-b.analysis.score)[0];
  const strongest = [...pairs].sort((a,b)=>b.analysis.score-a.analysis.score)[0];

  const summary = [];
  if (score >= 92) summary.push("Svært godt helhetsmatch.");
  else if (score >= 84) summary.push("Godt balansert system med få tydelige svakheter.");
  else if (score >= 75) summary.push("Fungerende kombinasjon, men med synlig oppgraderingspotensial.");
  else summary.push("Flere deler av kjeden bør vurderes nærmere.");

  if (strongest) summary.push(`Sterkeste ledd: ${strongest.from.brand} ${strongest.from.model} → ${strongest.to.brand} ${strongest.to.model}.`);
  if (weakest && weakest.analysis.score < 90) summary.push(`Mest å hente: ${weakest.from.brand} ${weakest.from.model} → ${weakest.to.brand} ${weakest.to.model}.`);

  return {score,pairs,summary};
}
