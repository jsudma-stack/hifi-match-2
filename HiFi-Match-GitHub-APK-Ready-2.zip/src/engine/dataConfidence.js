
export function dataConfidence(product) {
  if (!product) return 0;
  if (product.dataStatus === "verified") return 100;
  if (product.dataStatus === "partial") return 70;
  return 35;
}

export function systemDataConfidence(products) {
  if (!products?.length) return 0;
  return Math.round(products.reduce((s,p)=>s+dataConfidence(p),0)/products.length);
}
