
const tonePairs = {
  "varm:detaljert": 5,
  "detaljert:varm": 5,
  "varm:nøytral": 4,
  "nøytral:varm": 4,
  "naturlig:varm": 5,
  "varm:naturlig": 5,
  "nøytral:detaljert": 4,
  "detaljert:nøytral": 4,
  "åpen:varm": 4,
  "varm:åpen": 4
};

export function componentMatch(a, b) {
  if (!a || !b) return 0;
  const tone = tonePairs[`${a.tone}:${b.tone}`] ?? (a.tone === b.tone ? 3 : 3.5);
  const levelGap = Math.abs((a.level || 3) - (b.level || 3));
  const quality = Math.max(0, 5 - levelGap);
  return Math.round(((tone * 0.55 + quality * 0.45) / 5) * 100);
}

export function systemScore(list) {
  if (!list || list.length < 2) return 0;
  let sum = 0, count = 0;
  for (let i = 0; i < list.length - 1; i++) {
    sum += componentMatch(list[i], list[i + 1]);
    count++;
  }
  return Math.round(sum / count);
}
