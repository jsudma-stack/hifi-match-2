
import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

const SubscriptionContext = createContext(null);
const KEY = "@hifimatch/subscription";

export const FREE_LIMITS = {
  savedSystems: 1,
  advancedMatching: false,
  upgradeAdvice: false,
  unlimitedSystems: false
};

export function SubscriptionProvider({ children }) {
  const [plan, setPlan] = useState("free");
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const saved = await AsyncStorage.getItem(KEY);
        if (saved === "premium" || saved === "free") setPlan(saved);
      } finally {
        setLoaded(true);
      }
    })();
  }, []);

  async function setPlanForBeta(next) {
    setPlan(next);
    await AsyncStorage.setItem(KEY, next);
  }

  const isPremium = plan === "premium";

  const value = useMemo(() => ({
    plan,
    isPremium,
    loaded,
    setPlanForBeta,
    limits: isPremium ? {
      savedSystems: Infinity,
      advancedMatching: true,
      upgradeAdvice: true,
      unlimitedSystems: true
    } : FREE_LIMITS
  }), [plan, isPremium, loaded]);

  return (
    <SubscriptionContext.Provider value={value}>
      {children}
    </SubscriptionContext.Provider>
  );
}

export function useSubscription() {
  const ctx = useContext(SubscriptionContext);
  if (!ctx) throw new Error("useSubscription must be used inside SubscriptionProvider");
  return ctx;
}
