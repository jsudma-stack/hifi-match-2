
import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { systems as starterSystems } from "../data/systems";
import { useAuth } from "./AuthContext";
import { fetchCloudSystems, saveCloudSystem } from "../lib/cloudSystems";

const AppDataContext = createContext(null);
const PROFILE_KEY = "@hifimatch/profile";
const SYSTEMS_KEY = "@hifimatch/systems";

export function AppDataProvider({ children }) {
  const { user, cloudConfigured } = useAuth();
  const [profile, setProfileState] = useState({ name: "", experience: "Ny i HiFi" });
  const [systems, setSystems] = useState(starterSystems);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const [savedProfile, savedSystems] = await Promise.all([
          AsyncStorage.getItem(PROFILE_KEY),
          AsyncStorage.getItem(SYSTEMS_KEY)
        ]);
        if (savedProfile) setProfileState(JSON.parse(savedProfile));
        if (savedSystems) setSystems(JSON.parse(savedSystems));
      } finally {
        setLoaded(true);
      }
    })();
  }, []);


  useEffect(() => {
    if (!cloudConfigured || !user?.id) return;
    (async () => {
      try {
        const cloud = await fetchCloudSystems(user.id);
        if (cloud.length > 0) {
          setSystems(cloud);
          await AsyncStorage.setItem(SYSTEMS_KEY, JSON.stringify(cloud));
        }
      } catch (_) {}
    })();
  }, [user?.id, cloudConfigured]);

  async function saveProfile(next) {
    setProfileState(next);
    await AsyncStorage.setItem(PROFILE_KEY, JSON.stringify(next));
  }

  async function addSystem(system) {
    const next = [...systems, system];
    setSystems(next);
    await AsyncStorage.setItem(SYSTEMS_KEY, JSON.stringify(next));
    if (cloudConfigured && user?.id) {
      try { await saveCloudSystem(user.id, system); } catch (_) {}
    }
  }

  async function resetDemoSystems() {
    setSystems(starterSystems);
    await AsyncStorage.setItem(SYSTEMS_KEY, JSON.stringify(starterSystems));
  }

  const value = useMemo(() => ({
    profile, systems, loaded, saveProfile, addSystem, resetDemoSystems
  }), [profile, systems, loaded]);

  return <AppDataContext.Provider value={value}>{children}</AppDataContext.Provider>;
}

export function useAppData() {
  const ctx = useContext(AppDataContext);
  if (!ctx) throw new Error("useAppData must be used inside AppDataProvider");
  return ctx;
}
