
export const products = [
  { id:"eci5", brand:"Electrocompaniet", model:"ECI 5", type:"Integrert forsterker", tone:"varm", level:5 },
  { id:"ecd1", brand:"Electrocompaniet", model:"ECD 1", type:"DAC", tone:"nøytral", level:4 },
  { id:"xq40", brand:"KEF", model:"XQ40", type:"Høyttaler", tone:"detaljert", level:4 },
  { id:"dnp800", brand:"Denon", model:"DNP-800", type:"Streamer", tone:"nøytral", level:3 },
  { id:"dtr2000", brand:"Denon", model:"DTR-2000", type:"DAT", tone:"nøytral", level:4 },
  { id:"dcc600", brand:"Philips", model:"DCC 600", type:"DCC", tone:"myk", level:3 },
  { id:"sl1500", brand:"Technics", model:"SL-1500", type:"Platespiller", tone:"nøytral", level:4 },
  { id:"goldringelite", brand:"Goldring", model:"Elite", type:"Pickup", tone:"detaljert", level:4 },
  { id:"tubeboxs2", brand:"Pro-Ject", model:"Tube Box S2", type:"RIAA", tone:"varm", level:4 },
  { id:"project2x", brand:"Pro-Ject", model:"2X", type:"Platespiller", tone:"nøytral", level:4 },
  { id:"2mblue", brand:"Ortofon", model:"2M Blue", type:"Pickup", tone:"åpen", level:3 },
  { id:"mofiriaa", brand:"MOFI", model:"RIAA", type:"RIAA", tone:"nøytral", level:4 },

  { id:"ec47", brand:"Electrocompaniet", model:"EC 4.7", type:"Forforsterker", tone:"varm", level:5 },
  { id:"aw100dmb", brand:"Electrocompaniet", model:"AW100 DMB", type:"Effektforsterker", tone:"varm", level:5 },
  { id:"wiimultra", brand:"WiiM", model:"Ultra", type:"Streamer", tone:"nøytral", level:4 },
  { id:"toytower", brand:"Sonus Faber", model:"Toy Tower", type:"Høyttaler", tone:"varm", level:4 },
  { id:"ecp1", brand:"Electrocompaniet", model:"ECP 1", type:"RIAA", tone:"varm", level:4 },
  { id:"pll1000", brand:"Pioneer", model:"PL-L1000", type:"Platespiller", tone:"nøytral", level:4 },
  { id:"at33ev", brand:"Audio-Technica", model:"AT33EV", type:"Pickup", tone:"detaljert", level:4 },

  { id:"eci3", brand:"Electrocompaniet", model:"ECI 3", type:"Integrert forsterker", tone:"varm", level:4 },
  { id:"aztwo", brand:"Audio Note", model:"AZ-Two", type:"Høyttaler", tone:"naturlig", level:4 }
];
