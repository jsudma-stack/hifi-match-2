
export const productSources = {
  audio_technica_at33ev: {
    label:"Audio-Technica – AT33EV official datasheet",
    verified:["MC dual moving coil","15–50,000 Hz","0.3 mV output","10 ohm coil impedance","recommended load >100 ohm","1.8–2.2 g tracking force (2.0 g standard)","elliptical 0.3 x 0.7 mil","6.9 g"]
  },

  kef_xq40: {
    label:"KEF XQ40 brochure/service documentation",
    verified:["8 ohm nominal","3.2 ohm minimum","90 dB sensitivity","15–200 W amplifier requirement","45 Hz–55 kHz"]
  },
  electrocompaniet_aw100dmb: {
    label:"Electrocompaniet AW100DMB owner manual",
    verified:["2 x 100 W / 8 ohm","2 x 200 W / 4 ohm","2 x 350 W / 2 ohm","max peak current >80 A","1 V input sensitivity"]
  },
  sonusfaber_toytower: {
    label:"Sonus Faber Toy Tower data sheet",
    verified:["8 ohm nominal","89 dB SPL","35–200 W without clipping","45 Hz–25 kHz","3-way vented box"]
  },
  electrocompaniet_ecp1: {
    label:"Electrocompaniet ECP 1 official product/specification information",
    verified:["MM and MC operation","38.4 dB MM gain","approximately 73 dB MC gain"]
  },

  electrocompaniet_eci5: {
    label:"Electrocompaniet – ECI 5 archived product specifications",
    verified:["2 x 120 W / 8 ohm","max peak current >80 A","stable down to 0.5 ohm"]
  },
  electrocompaniet_eci3: {
    label:"Electrocompaniet – ECI 3 official specifications",
    verified:["2 x 70 W / 8 ohm","2 x 120 W / 4 ohm","2 x 160 W / 2 ohm","max peak current >60 A","stable down to 0.5 ohm"]
  },
  audionote_aztwo: {
    label:"Audio Note – AZ-Two owner information",
    verified:["6 ohm characteristic impedance","93 dB / 1 W / 1 m","7 W minimum amplifier power","120 W maximum unclipped amplifier power","8-inch paper cone bass driver"]
  },
  project_tubeboxs2: {
    label:"Pro-Ject – Tube Box S2 official product information",
    verified:["MM and MC","40/43/50/60/63 dB gain","10/100/1k/2k/47k ohm loading options"]
  },
  goldring_elite: {
    label:"Goldring Elite documentation",
    verified:["MC","0.5 mV output","100 ohm load reference","1.7 g tracking force"]
  }
};
