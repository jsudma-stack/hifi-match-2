
export const catalog = [
  {
    id:"eci5", brand:"Electrocompaniet", model:"ECI 5", type:"integrated_amp",
    tone:{warmth:4.5, detail:4.0, dynamics:4.2, smoothness:4.5},
    tier:5, power8:120, power4:null, ampClass:"AB", maxPeakCurrentA:80, stableToOhm:0.5, dataStatus:"verified", sourceKey:"electrocompaniet_eci5"
  },
  {
    id:"ecd1", brand:"Electrocompaniet", model:"ECD 1", type:"dac",
    tone:{warmth:3.8, detail:4.3, dynamics:4.0, smoothness:4.2},
    tier:4, dataStatus:"unverified"
  },
  {
    id:"xq40", brand:"KEF", model:"XQ40", type:"speaker",
    tone:{warmth:3.2, detail:4.5, dynamics:4.0, smoothness:3.7},
    tier:4, impedanceNominal:8, impedanceMin:3.2, sensitivity:90, recommendedPowerMin:15, recommendedPowerMax:200, frequencyHz:[45,55000], dataStatus:"verified", sourceKey:"kef_xq40"
  },
  {
    id:"ec47", brand:"Electrocompaniet", model:"EC 4.7", type:"preamp",
    tone:{warmth:4.5, detail:4.1, dynamics:4.1, smoothness:4.6},
    tier:5, dataStatus:"unverified"
  },
  {
    id:"aw100dmb", brand:"Electrocompaniet", model:"AW100 DMB", type:"power_amp",
    tone:{warmth:4.4, detail:4.2, dynamics:4.6, smoothness:4.4},
    tier:5, power8:100, power4:200, power2:350, ampClass:"AB", maxPeakCurrentA:80, inputSensitivityV:1, dataStatus:"verified", sourceKey:"electrocompaniet_aw100dmb"
  },
  {
    id:"toytower", brand:"Sonus Faber", model:"Toy Tower", type:"speaker",
    tone:{warmth:4.4, detail:3.8, dynamics:3.7, smoothness:4.6},
    tier:4, impedanceNominal:8, impedanceMin:4.2, sensitivity:89, recommendedPowerMin:35, recommendedPowerMax:200, frequencyHz:[45,25000], dataStatus:"verified", sourceKey:"sonusfaber_toytower"
  },
  {
    id:"eci3", brand:"Electrocompaniet", model:"ECI 3", type:"integrated_amp",
    tone:{warmth:4.4, detail:3.9, dynamics:4.0, smoothness:4.4},
    tier:4, power8:70, power4:120, power2:160, ampClass:"AB", maxPeakCurrentA:60, stableToOhm:0.5, dataStatus:"verified", sourceKey:"electrocompaniet_eci3"
  },
  {
    id:"aztwo", brand:"Audio Note", model:"AZ-Two", type:"speaker",
    tone:{warmth:4.3, detail:3.8, dynamics:3.9, smoothness:4.5},
    tier:4, impedanceNominal:6, impedanceMin:null, sensitivity:93, recommendedPowerMin:7, recommendedPowerMax:120, woofer:"8-inch paper cone", dataStatus:"verified", sourceKey:"audionote_aztwo"
  },
  {
    id:"pll1000", brand:"Pioneer", model:"PL-L1000", type:"turntable",
    tone:{warmth:3.4, detail:4.0, dynamics:4.0, smoothness:3.8},
    tier:4, dataStatus:"unverified"
  },
  {
    id:"at33ev", brand:"Audio-Technica", model:"AT33EV", type:"cartridge",
    cartridgeType:"MC", outputMv:0.3, coilImpedanceOhm:10, recommendedLoadOhm:100, trackingForceG:[1.8,2.2], trackingForceStandardG:2.0, frequencyHz:[15,50000], stylus:"Elliptical 0.3 x 0.7 mil", cantilever:"Tapered Duralumin", weightG:6.9,
    tone:{warmth:3.4, detail:4.4, dynamics:4.1, smoothness:3.9},
    tier:4, dataStatus:"verified", sourceKey:"audio_technica_at33ev"
  },
  {
    id:"ecp1", brand:"Electrocompaniet", model:"ECP 1", type:"phono",
    supportsMM:true, supportsMC:true, gainDbMin:38.4, gainDbMax:73, resistanceLoading:"MC current input / MM mode", 
    tone:{warmth:4.2, detail:4.0, dynamics:4.0, smoothness:4.4},
    tier:4, dataStatus:"verified", sourceKey:"electrocompaniet_ecp1"
  },
  {
    id:"sl1500", brand:"Technics", model:"SL-1500", type:"turntable",
    tone:{warmth:3.3, detail:4.1, dynamics:4.1, smoothness:3.7},
    tier:4, dataStatus:"unverified"
  },
  {
    id:"goldringelite", brand:"Goldring", model:"Elite", type:"cartridge",
    cartridgeType:"MC", outputMv:0.5, recommendedLoadOhm:100, trackingForceG:1.7,
    tone:{warmth:3.5, detail:4.5, dynamics:4.2, smoothness:4.0},
    tier:4, dataStatus:"verified", sourceKey:"goldring_elite"
  },
  {
    id:"tubeboxs2", brand:"Pro-Ject", model:"Tube Box S2", type:"phono",
    supportsMM:true, supportsMC:true, gainDbMin:40, gainDbMax:63, inputImpedanceOhm:[10,100,1000,2000,47000],
    tone:{warmth:4.5, detail:3.9, dynamics:3.8, smoothness:4.6},
    tier:4, dataStatus:"verified", sourceKey:"project_tubeboxs2"
  }
];

export function getProduct(id) {
  return catalog.find(p => p.id === id);
}
