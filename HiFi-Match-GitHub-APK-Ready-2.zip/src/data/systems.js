
export const systems = [
  {
    id: "system-1",
    name: "Anlegg 1",
    score: 93,
    title: "ECI 5 + KEF XQ40",
    sound: "Varm, kraftfull og detaljert",
    components: [
      "Electrocompaniet ECI 5",
      "Electrocompaniet ECD 1",
      "KEF XQ40",
      "Denon DNP-800",
      "Denon DTR-2000",
      "Philips DCC 600",
      "Technics SL-1500 + Goldring Elite",
      "Pro-Ject Tube Box S2",
      "Pro-Ject 2X + Ortofon 2M Blue",
      "MOFI RIAA"
    ]
  },
  {
    id: "system-2",
    name: "Anlegg 2",
    score: 94,
    title: "EC 4.7 + AW100 DMB + Toy Tower",
    sound: "Varm, raffinert og musikalsk",
    components: [
      "Electrocompaniet EC 4.7",
      "Electrocompaniet AW100 DMB",
      "WiiM Ultra",
      "Sonus Faber Toy Tower",
      "Electrocompaniet ECP 1",
      "Pioneer PL-L1000",
      "Audio-Technica AT33EV"
    ]
  },
  {
    id: "system-3",
    name: "Anlegg 3",
    score: 90,
    title: "ECI 3 + Audio Note AZ-Two",
    sound: "Naturlig, åpen og engasjerende",
    components: [
      "Electrocompaniet ECI 3",
      "Denon DNP-800",
      "Audio Note AZ-Two"
    ]
  }
];
