
export const demoChains = [
  {
    id:"demo1",
    name:"Anlegg 1 – hovedkjede",
    productIds:["ecd1","eci5","xq40"]
  },
  {
    id:"demo1vinyl",
    name:"Anlegg 1 – vinyl",
    productIds:["sl1500","goldringelite","tubeboxs2","eci5","xq40"]
  },
  {
    id:"demo2",
    name:"Anlegg 2 – hovedkjede",
    productIds:["ec47","aw100dmb","toytower"]
  },
  {
    id:"demo2vinyl",
    name:"Anlegg 2 – vinyl",
    productIds:["pll1000","at33ev","ecp1","ec47","aw100dmb","toytower"]
  },
  {
    id:"demo3",
    name:"Anlegg 3",
    productIds:["eci3","aztwo"]
  }
];
