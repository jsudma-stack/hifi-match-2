
export const colors = {
  bg: "#05090d",
  panel: "#0c1720",
  panel2: "#101d28",
  text: "#f7f7f7",
  muted: "#a7b1ba",
  gold: "#e3aa35",
  green: "#74d64d",
  border: "#213544"
};
