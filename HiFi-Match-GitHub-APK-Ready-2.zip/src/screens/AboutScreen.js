
import React from "react";
import { SafeAreaView, ScrollView, Text, View, StyleSheet } from "react-native";
import { colors } from "../theme";

export default function AboutScreen() {
  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.eyebrow}>HIFI-MATCH BETA</Text>
        <Text style={styles.title}>Om appen</Text>
        <Text style={styles.body}>
          HiFi-Match hjelper førstegangskjøpere og entusiaster med å forstå hvilke HiFi-komponenter som passer sammen.
        </Text>

        <View style={styles.card}>
          <Text style={styles.heading}>Beta-versjon</Text>
          <Text style={styles.body}>
            Match-score og produktdata er under utvikling. Enkelte testdata kan være foreløpige og skal ikke behandles som produsentspesifikasjoner.
          </Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.heading}>Personvern</Text>
          <Text style={styles.body}>
            Lokal beta lagrer profil og anlegg på enheten. Skylagring aktiveres først når backend er konfigurert.
          </Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.heading}>Rettigheter</Text>
          <Text style={styles.body}>© 2026 Jørn Sudmann. Alle rettigheter forbeholdt.</Text>
        </View>

        <Text style={styles.version}>Versjon 0.7.0 · Beta</Text>
      </ScrollView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:colors.bg},
  container:{padding:18,gap:14},
  eyebrow:{color:colors.gold,fontWeight:"900",letterSpacing:1},
  title:{color:colors.text,fontSize:30,fontWeight:"900"},
  body:{color:colors.muted,lineHeight:22},
  card:{backgroundColor:colors.panel,borderWidth:1,borderColor:colors.border,borderRadius:18,padding:18,gap:8},
  heading:{color:colors.text,fontSize:18,fontWeight:"900"},
  version:{color:colors.muted,fontSize:12,textAlign:"center",marginTop:10}
});
