
import React from "react";
import { SafeAreaView, ScrollView, Text, View, StyleSheet } from "react-native";
import { colors } from "../theme";
import PrimaryButton from "../components/PrimaryButton";
import { useSubscription } from "../context/SubscriptionContext";

const features = [
  "Ubegrenset antall egne anlegg",
  "Avansert Match-score",
  "Oppgraderingsforslag",
  "Sammenligning av komponenter",
  "Premium-analyse av hele signalkjeden",
  "Senere: bruktmarked og prisvarsling"
];

export default function PremiumScreen() {
  const { isPremium, setPlanForBeta } = useSubscription();

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.eyebrow}>HIFI-MATCH PREMIUM</Text>
        <Text style={styles.title}>
          {isPremium ? "Premium er aktivert" : "Få mer ut av anlegget ditt"}
        </Text>
        <Text style={styles.sub}>
          Gratisversjonen skal være nyttig for førstegangskjøpere. Premium er laget for dem som vil analysere,
          sammenligne og bygge flere HiFi-oppsett.
        </Text>

        <View style={styles.card}>
          {features.map((f, i) => (
            <Text key={i} style={styles.feature}>✓ {f}</Text>
          ))}
        </View>

        <View style={styles.priceCard}>
          <Text style={styles.plan}>Premium</Text>
          <Text style={styles.price}>Pris settes i App Store / Google Play</Text>
          <Text style={styles.note}>
            Betaversjonen bruker en testbryter. Ingen betaling blir belastet.
          </Text>
          <PrimaryButton
            title={isPremium ? "Bytt til gratis (beta)" : "Aktiver Premium-test"}
            onPress={() => setPlanForBeta(isPremium ? "free" : "premium")}
          />
        </View>

        <Text style={styles.legal}>
          Ved lansering skal kjøp og gjenoppretting håndteres gjennom den aktuelle appbutikken.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:colors.bg},
  container:{padding:18,gap:14},
  eyebrow:{color:colors.gold,fontWeight:"900",letterSpacing:1},
  title:{color:colors.text,fontSize:30,fontWeight:"900"},
  sub:{color:colors.muted,lineHeight:22},
  card:{backgroundColor:colors.panel,borderColor:colors.border,borderWidth:1,borderRadius:18,padding:18,gap:12},
  feature:{color:colors.text,fontSize:16,lineHeight:23},
  priceCard:{backgroundColor:colors.panel2,borderColor:colors.gold,borderWidth:1,borderRadius:18,padding:18,gap:12},
  plan:{color:colors.gold,fontWeight:"900",fontSize:20},
  price:{color:colors.text,fontWeight:"900",fontSize:22},
  note:{color:colors.muted,lineHeight:21},
  legal:{color:colors.muted,fontSize:12,lineHeight:18}
});
