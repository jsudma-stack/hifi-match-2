
import React, { useMemo, useState } from "react";
import { SafeAreaView, ScrollView, TextInput, Text, View, StyleSheet } from "react-native";
import { colors } from "../theme";
import { products } from "../data/products";

export default function DatabaseScreen() {
  const [query, setQuery] = useState("");
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return products;
    return products.filter(p => `${p.brand} ${p.model} ${p.type}`.toLowerCase().includes(q));
  }, [query]);

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>HiFi-database</Text>
        <Text style={styles.sub}>Første interne database med komponentene fra testanleggene.</Text>
        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder="Søk merke, modell eller type"
          placeholderTextColor={colors.muted}
          style={styles.search}
        />
        {filtered.map(p => (
          <View style={styles.card} key={p.id}>
            <Text style={styles.brand}>{p.brand}</Text>
            <Text style={styles.model}>{p.model}</Text>
            <Text style={styles.meta}>{p.type} · lyd: {p.tone}</Text>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:colors.bg},
  container:{padding:18,gap:12},
  title:{fontSize:30,fontWeight:"900",color:colors.text},
  sub:{color:colors.muted,lineHeight:21},
  search:{backgroundColor:colors.panel,borderWidth:1,borderColor:colors.border,borderRadius:14,padding:14,color:colors.text},
  card:{backgroundColor:colors.panel,borderWidth:1,borderColor:colors.border,borderRadius:16,padding:16},
  brand:{color:colors.gold,fontWeight:"800"},
  model:{color:colors.text,fontSize:20,fontWeight:"800",marginTop:3},
  meta:{color:colors.muted,marginTop:6}
});
