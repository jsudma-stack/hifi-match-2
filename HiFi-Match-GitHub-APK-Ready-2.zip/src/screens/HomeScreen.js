
import React from "react";
import { SafeAreaView, View, Text, StyleSheet, ScrollView, Pressable } from "react-native";
import { colors } from "../theme";
import PrimaryButton from "../components/PrimaryButton";

export default function HomeScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.brand}>HiFi-<Text style={styles.gold}>Match</Text></Text>
        <Text style={styles.tagline}>Finn din perfekte lyd</Text>
        <Text style={styles.beta}>BETA 0.7 · TESTVERSJON</Text>

        <View style={styles.hero}>
          <Text style={styles.heroTitle}>Velkommen til HiFi-Match</Text>
          <Text style={styles.heroText}>Enklere valg. Bedre lyd. Mer musikkglede.</Text>
          <PrimaryButton title="Mitt første HiFi-anlegg" onPress={() => navigation.navigate("FirstSystem")} />
        </View>

        <View style={styles.grid}>
          <Tile title="Mine anlegg" text="Se systemene dine og hvordan komponentene passer sammen." onPress={() => navigation.navigate("Systems")} />
          <Tile title="Finn en match" text="Finn komponenter som passer til det du allerede har." onPress={() => navigation.navigate("MatchLab")} />
          <Tile title="Bygg anlegg" text="Sett sammen et komplett system før du kjøper." />
          <Tile title="HiFi-database" text="Søk i komponenter, tekniske data og match-vurderinger." onPress={() => navigation.navigate("Database")} />
          <Tile title="Min profil" text="Lagre navn og HiFi-erfaring på denne enheten." onPress={() => navigation.navigate("Profile")} />
          <Tile title="Konto / innlogging" text="Opprett konto og klargjør synkronisering mellom enheter." onPress={() => navigation.navigate("Auth")} />
          <Tile title="HiFi-Match Premium" text="Avansert matching, flere anlegg og oppgraderingsforslag." onPress={() => navigation.navigate("Premium")} />
          <Tile title="Om HiFi-Match" text="Beta-info, personvern og rettigheter." onPress={() => navigation.navigate("About")} />
        </View>
        <Text style={styles.copyright}>© 2026 Jørn Sudmann. Alle rettigheter forbeholdt.</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

function Tile({ title, text, onPress }) {
  return (
    <Pressable onPress={onPress} style={styles.tile}>
      <Text style={styles.tileTitle}>{title}</Text>
      <Text style={styles.tileText}>{text}</Text>
      <Text style={styles.arrow}>›</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  container: { padding: 18, gap: 14 },
  brand: { fontSize: 34, fontWeight: "900", color: colors.text, marginTop: 8 },
  gold: { color: colors.gold },
  tagline: { color: colors.muted, marginTop: -6, marginBottom: 6 },
  beta: { color: colors.gold, fontSize: 11, fontWeight: "900", letterSpacing: 1, marginBottom: 8 },
  hero: { backgroundColor: colors.panel2, borderColor: colors.border, borderWidth: 1, borderRadius: 22, padding: 22, gap: 14 },
  heroTitle: { color: colors.text, fontSize: 28, fontWeight: "800" },
  heroText: { color: colors.muted, fontSize: 16, lineHeight: 23 },
  grid: { gap: 12 },
  tile: { backgroundColor: colors.panel, borderColor: colors.border, borderWidth: 1, borderRadius: 18, padding: 18, minHeight: 120 },
  tileTitle: { color: colors.text, fontWeight: "800", fontSize: 20 },
  tileText: { color: colors.muted, marginTop: 7, lineHeight: 20, maxWidth: "90%" },
  arrow: { position: "absolute", right: 16, bottom: 12, color: colors.gold, fontSize: 30 },
  copyright: { color: colors.muted, fontSize: 12, textAlign: "center", marginTop: 16, marginBottom: 8 }
});
