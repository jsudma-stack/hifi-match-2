
import React from "react";
import { SafeAreaView, ScrollView, View, Text, StyleSheet } from "react-native";
import { colors } from "../theme";
import { useAppData } from "../context/AppDataContext";

export default function SystemDetailsScreen({ route }) {
  const { systems } = useAppData();
  const system = systems.find(s => s.id === route.params?.id) || systems[0];
  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.eyebrow}>{system.name}</Text>
        <Text style={styles.title}>{system.title}</Text>
        <View style={styles.scoreCard}>
          <Text style={styles.score}>{system.score}%</Text>
          <Text style={styles.label}>Match-score</Text>
        </View>
        <Text style={styles.sound}>{system.sound}</Text>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Signalvei / komponenter</Text>
          {system.components.map((c, i) => (
            <Text key={i} style={styles.component}>{i+1}. {c}</Text>
          ))}
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>HiFi-Match vurdering</Text>
          <Text style={styles.body}>Sterkt helhetsoppsett. Neste versjon av matchmotoren skal vurdere effekt, impedans, følsomhet, pickup/RIAA-kompatibilitet og lydkarakter.</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:colors.bg},
  container:{padding:18,gap:14},
  eyebrow:{color:colors.gold,fontWeight:"900"},
  title:{color:colors.text,fontSize:28,fontWeight:"900"},
  scoreCard:{backgroundColor:colors.panel,borderWidth:1,borderColor:colors.border,borderRadius:18,padding:18},
  score:{color:colors.green,fontSize:54,fontWeight:"900"},
  label:{color:colors.muted},
  sound:{color:colors.muted,fontSize:16},
  card:{backgroundColor:colors.panel,borderWidth:1,borderColor:colors.border,borderRadius:18,padding:18},
  cardTitle:{color:colors.text,fontWeight:"900",fontSize:18,marginBottom:8},
  component:{color:colors.muted,lineHeight:23},
  body:{color:colors.muted,lineHeight:22}
});
