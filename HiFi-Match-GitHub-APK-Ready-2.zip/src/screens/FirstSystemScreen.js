
import React, { useMemo, useState } from "react";
import { SafeAreaView, ScrollView, View, Text, StyleSheet, Pressable } from "react-native";
import { colors } from "../theme";
import PrimaryButton from "../components/PrimaryButton";

const questions = [
  ["budget", "Hva er budsjettet ditt?", ["Under 10 000 kr", "10 000–20 000 kr", "20 000–30 000 kr", "30 000–50 000 kr", "Over 50 000 kr"]],
  ["music", "Hva hører du mest på?", ["Rock / Pop", "Elektronisk", "Jazz", "Klassisk", "Litt av alt"]],
  ["source", "Hvordan hører du på musikk?", ["Spotify / Tidal", "Vinyl", "CD", "TV / Film", "Flere kilder"]],
  ["room", "Hvor stort er rommet?", ["Lite", "Middels", "Stort"]],
  ["sound", "Hva er viktigst for deg?", ["Mye bass", "Varm og behagelig lyd", "Mye detaljer", "Spille høyt", "Balansert lyd"]],
  ["buy", "Nytt, brukt eller begge deler?", ["Nytt", "Brukt", "Begge deler"]]
];

export default function FirstSystemScreen() {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState({});
  const done = step >= questions.length;
  const q = questions[step];
  const selected = !done ? answers[q[0]] : null;

  const recommendation = useMemo(() => {
    // Placeholder match logic for beta prototype.
    const warm = answers.sound === "Varm og behagelig lyd";
    const used = answers.buy === "Brukt" || answers.buy === "Begge deler";
    return {
      score: 96,
      title: "Enkelt og oppgraderbart startanlegg",
      note: warm
        ? "Vi prioriterer en litt varmere og behagelig lydsignatur."
        : "Vi prioriterer god balanse og enkel bruk.",
      market: used ? "Vis både nye og brukte alternativer." : "Vis nye produkter først."
    };
  }, [answers]);

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        {!done ? (
          <>
            <Text style={styles.eyebrow}>MITT FØRSTE HIFI-ANLEGG</Text>
            <Text style={styles.title}>{q[1]}</Text>
            <Text style={styles.progress}>Spørsmål {step + 1} av {questions.length}</Text>
            <View style={styles.bar}><View style={[styles.barFill, { width: `${((step + 1) / questions.length) * 100}%` }]} /></View>

            <View style={styles.card}>
              {q[2].map(option => (
                <Pressable
                  key={option}
                  onPress={() => setAnswers({ ...answers, [q[0]]: option })}
                  style={[styles.choice, selected === option && styles.choiceSelected]}
                >
                  <Text style={styles.choiceText}>{option}</Text>
                </Pressable>
              ))}
              <PrimaryButton
                title={step === questions.length - 1 ? "Se anbefalt anlegg" : "Neste"}
                disabled={!selected}
                onPress={() => selected && setStep(step + 1)}
              />
            </View>
          </>
        ) : (
          <View style={styles.card}>
            <Text style={styles.eyebrow}>RESULTAT</Text>
            <Text style={styles.title}>{recommendation.title}</Text>
            <Text style={styles.score}>{recommendation.score}%</Text>
            <Text style={styles.body}>{recommendation.note}</Text>
            <Text style={styles.body}>{recommendation.market}</Text>

            <View style={styles.recBox}>
              <Text style={styles.recTitle}>Forslag til oppsett</Text>
              <Text style={styles.body}>• Streamer</Text>
              <Text style={styles.body}>• Integrert forsterker</Text>
              <Text style={styles.body}>• Høyttalere tilpasset rommet</Text>
              <Text style={styles.body}>• Riktige kabler</Text>
            </View>

            <PrimaryButton title="Start på nytt" outline onPress={() => { setStep(0); setAnswers({}); }} />
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  container: { padding: 18, gap: 14 },
  eyebrow: { color: colors.gold, fontSize: 13, fontWeight: "900", letterSpacing: 1 },
  title: { color: colors.text, fontSize: 28, fontWeight: "900", marginTop: 4 },
  progress: { color: colors.muted },
  bar: { height: 7, backgroundColor: "#15242e", borderRadius: 20, overflow: "hidden" },
  barFill: { height: "100%", backgroundColor: colors.gold },
  card: { backgroundColor: colors.panel, borderColor: colors.border, borderWidth: 1, borderRadius: 18, padding: 18, gap: 12 },
  choice: { borderWidth: 1, borderColor: colors.border, borderRadius: 12, padding: 14, backgroundColor: "#09131b" },
  choiceSelected: { borderColor: colors.gold, backgroundColor: "#1b1710" },
  choiceText: { color: colors.text, fontSize: 16 },
  score: { color: colors.green, fontSize: 54, fontWeight: "900" },
  body: { color: colors.muted, fontSize: 16, lineHeight: 23 },
  recBox: { borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 12, gap: 5 },
  recTitle: { color: colors.text, fontWeight: "800", fontSize: 18 }
});
