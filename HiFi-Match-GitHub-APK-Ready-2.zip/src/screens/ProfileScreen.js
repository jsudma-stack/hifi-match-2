
import React, { useState } from "react";
import { SafeAreaView, ScrollView, Text, TextInput, View, StyleSheet, Pressable } from "react-native";
import { colors } from "../theme";
import PrimaryButton from "../components/PrimaryButton";
import { useAppData } from "../context/AppDataContext";
import { useAuth } from "../context/AuthContext";

export default function ProfileScreen() {
  const { profile, saveProfile } = useAppData();
  const { user, signOut, cloudConfigured } = useAuth();
  const [name, setName] = useState(profile.name || "");
  const [experience, setExperience] = useState(profile.experience || "Ny i HiFi");
  const [saved, setSaved] = useState(false);
  const levels = ["Ny i HiFi", "Litt erfaring", "Entusiast"];

  async function save() {
    await saveProfile({ name: name.trim(), experience });
    setSaved(true);
  }

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>Min profil</Text>
        <Text style={styles.sub}>Profilen brukes til å gjøre anbefalingene enklere og mer relevante.</Text>
        <View style={styles.accountBox}>
          <Text style={styles.label}>Konto</Text>
          <Text style={styles.accountText}>{user?.email || (cloudConfigured ? "Ikke innlogget" : "Skylagring ikke konfigurert")}</Text>
          {user ? <PrimaryButton title="Logg ut" outline onPress={signOut} /> : null}
        </View>

        <View style={styles.card}>
          <Text style={styles.label}>Navn</Text>
          <TextInput
            value={name}
            onChangeText={t => { setName(t); setSaved(false); }}
            placeholder="Skriv navnet ditt"
            placeholderTextColor={colors.muted}
            style={styles.input}
          />

          <Text style={styles.label}>HiFi-erfaring</Text>
          {levels.map(level => (
            <Pressable
              key={level}
              onPress={() => { setExperience(level); setSaved(false); }}
              style={[styles.choice, experience === level && styles.selected]}
            >
              <Text style={styles.choiceText}>{level}</Text>
            </Pressable>
          ))}

          <PrimaryButton title={saved ? "Lagret ✓" : "Lagre profil"} onPress={save} />
        </View>

        <Text style={styles.rights}>© 2026 Jørn Sudmann. Alle rettigheter forbeholdt.</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:colors.bg},
  container:{padding:18,gap:14},
  title:{fontSize:30,fontWeight:"900",color:colors.text},
  sub:{color:colors.muted,lineHeight:21},
  card:{backgroundColor:colors.panel,borderColor:colors.border,borderWidth:1,borderRadius:18,padding:18,gap:12},
  label:{color:colors.text,fontWeight:"800",marginTop:4},
  input:{backgroundColor:"#09131b",borderWidth:1,borderColor:colors.border,borderRadius:12,padding:14,color:colors.text},
  choice:{borderWidth:1,borderColor:colors.border,borderRadius:12,padding:14,backgroundColor:"#09131b"},
  selected:{borderColor:colors.gold,backgroundColor:"#1b1710"},
  choiceText:{color:colors.text},
  accountBox:{backgroundColor:colors.panel,borderColor:colors.border,borderWidth:1,borderRadius:16,padding:16,gap:10},
  accountText:{color:colors.muted},
  rights:{color:colors.muted,fontSize:12,textAlign:"center",marginTop:18}
});
