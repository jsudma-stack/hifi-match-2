
import React, { useState } from "react";
import { SafeAreaView, ScrollView, Text, TextInput, View, StyleSheet } from "react-native";
import { colors } from "../theme";
import PrimaryButton from "../components/PrimaryButton";
import { useAppData } from "../context/AppDataContext";
import { useSubscription } from "../context/SubscriptionContext";
import PremiumGate from "../components/PremiumGate";

export default function AddSystemScreen({ navigation }) {
  const { systems, addSystem } = useAppData();
  const { isPremium } = useSubscription();
  const userSystemCount = systems.filter(s => String(s.id).startsWith("user-")).length;
  const [name, setName] = useState("");
  const [amp, setAmp] = useState("");
  const [speakers, setSpeakers] = useState("");
  const [source, setSource] = useState("");

  async function save() {
    const components = [amp, source, speakers].map(x => x.trim()).filter(Boolean);
    if (!name.trim() || components.length < 2) return;

    await addSystem({
      id: `user-${Date.now()}`,
      name: name.trim(),
      title: [amp.trim(), speakers.trim()].filter(Boolean).join(" + "),
      score: 0,
      sound: "Ikke analysert ennå",
      components
    });
    navigation.goBack();
  }

  const valid = name.trim() && [amp, source, speakers].filter(x => x.trim()).length >= 2;

  if (!isPremium && userSystemCount >= 1) {
    return (
      <SafeAreaView style={styles.safe}>
        <ScrollView contentContainerStyle={styles.container}>
          <Text style={styles.title}>Legg til anlegg</Text>
          <PremiumGate navigation={navigation} title="Flere anlegg med Premium" text="Gratisbrukere kan lagre ett eget anlegg. Premium gir ubegrenset antall." />
        </ScrollView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>Legg til anlegg</Text>
        <Text style={styles.sub}>Dette er den enkle beta-flyten. Flere komponenttyper kommer etterpå.</Text>

        <View style={styles.card}>
          <Field label="Navn på anlegget" value={name} setValue={setName} placeholder={`Anlegg ${systems.length + 1}`} />
          <Field label="Forsterker" value={amp} setValue={setAmp} placeholder="F.eks. Electrocompaniet ECI 5" />
          <Field label="Streamer / kilde" value={source} setValue={setSource} placeholder="F.eks. WiiM Ultra" />
          <Field label="Høyttalere" value={speakers} setValue={setSpeakers} placeholder="F.eks. KEF XQ40" />
          <PrimaryButton title="Lagre anlegg" onPress={save} disabled={!valid} />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function Field({ label, value, setValue, placeholder }) {
  return (
    <View style={{ gap: 6 }}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={setValue}
        placeholder={placeholder}
        placeholderTextColor={colors.muted}
        style={styles.input}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:colors.bg},
  container:{padding:18,gap:14},
  title:{fontSize:30,fontWeight:"900",color:colors.text},
  sub:{color:colors.muted,lineHeight:21},
  card:{backgroundColor:colors.panel,borderColor:colors.border,borderWidth:1,borderRadius:18,padding:18,gap:14},
  label:{color:colors.text,fontWeight:"800"},
  input:{backgroundColor:"#09131b",borderWidth:1,borderColor:colors.border,borderRadius:12,padding:14,color:colors.text}
});
