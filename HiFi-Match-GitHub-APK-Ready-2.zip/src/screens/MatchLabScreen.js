
import React, { useMemo, useState } from "react";
import { SafeAreaView, ScrollView, Text, View, StyleSheet, Pressable } from "react-native";
import { colors } from "../theme";
import { demoChains } from "../data/demoChains";
import { getProduct } from "../data/catalog";
import { analyzeSystem } from "../engine/matchEngineV2";
import { systemDataConfidence } from "../engine/dataConfidence";

export default function MatchLabScreen() {
  const [chainId, setChainId] = useState(demoChains[0].id);
  const chain = demoChains.find(c => c.id === chainId) || demoChains[0];

  const result = useMemo(() => {
    const products = chain.productIds.map(getProduct).filter(Boolean);
    return { products, confidence: systemDataConfidence(products), ...analyzeSystem(products) };
  }, [chainId]);

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.eyebrow}>MATCH-MOTOR BETA</Text>
        <Text style={styles.title}>Hvor godt passer anlegget sammen?</Text>
        <Text style={styles.sub}>
          Denne analysen viser både totalscore og hvorfor hvert ledd får sin vurdering.
        </Text>

        <View style={styles.selector}>
          {demoChains.map(c => (
            <Pressable key={c.id} onPress={() => setChainId(c.id)} style={[styles.choice, chainId === c.id && styles.choiceActive]}>
              <Text style={styles.choiceText}>{c.name}</Text>
            </Pressable>
          ))}
        </View>

        <View style={styles.scoreCard}>
          <Text style={styles.score}>{result.score}%</Text>
          <Text style={styles.scoreLabel}>Samlet Match-score</Text>
          <Text style={styles.confidence}>Datagrunnlag: {result.confidence}% verifisert</Text>
          {result.summary.map((s,i)=><Text key={i} style={styles.summary}>• {s}</Text>)}
        </View>

        {result.pairs.map((p,i)=>(
          <View key={i} style={styles.card}>
            <View style={styles.row}>
              <Text style={styles.pairTitle}>{p.from.brand} {p.from.model}</Text>
              <Text style={styles.arrow}>→</Text>
              <Text style={styles.pairTitle}>{p.to.brand} {p.to.model}</Text>
            </View>
            <Text style={styles.pairScore}>{p.analysis.score}%</Text>

            {p.analysis.breakdown.map((b,j)=>(
              <View key={j} style={styles.breakRow}>
                <Text style={styles.breakName}>{b.name}</Text>
                <Text style={styles.breakValue}>{Math.round(b.value)}%</Text>
              </View>
            ))}

            <View style={styles.reasonBox}>
              {p.analysis.reasons.slice(0,5).map((r,j)=><Text key={j} style={styles.reason}>• {r}</Text>)}
            </View>
          </View>
        ))}

        <Text style={styles.note}>
          Beta: enkelte tekniske verdier i testkatalogen er foreløpige demo-/estimatdata og skal verifiseres før offentlig lansering.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:colors.bg},
  container:{padding:18,gap:14},
  eyebrow:{color:colors.gold,fontWeight:"900",letterSpacing:1},
  title:{color:colors.text,fontSize:29,fontWeight:"900"},
  sub:{color:colors.muted,lineHeight:21},
  selector:{gap:8},
  choice:{borderWidth:1,borderColor:colors.border,borderRadius:12,padding:12,backgroundColor:colors.panel},
  choiceActive:{borderColor:colors.gold,backgroundColor:"#1b1710"},
  choiceText:{color:colors.text,fontWeight:"700"},
  scoreCard:{backgroundColor:colors.panel2,borderWidth:1,borderColor:colors.gold,borderRadius:18,padding:18,gap:7},
  score:{color:colors.green,fontSize:56,fontWeight:"900"},
  scoreLabel:{color:colors.text,fontWeight:"900",fontSize:18},
  summary:{color:colors.muted,lineHeight:20},
  confidence:{color:colors.gold,fontWeight:"800"},
  card:{backgroundColor:colors.panel,borderWidth:1,borderColor:colors.border,borderRadius:18,padding:16,gap:10},
  row:{flexDirection:"row",alignItems:"center",gap:7,flexWrap:"wrap"},
  pairTitle:{color:colors.text,fontWeight:"800",flexShrink:1},
  arrow:{color:colors.gold,fontWeight:"900"},
  pairScore:{color:colors.green,fontSize:32,fontWeight:"900"},
  breakRow:{flexDirection:"row",justifyContent:"space-between",gap:10},
  breakName:{color:colors.muted},
  breakValue:{color:colors.text,fontWeight:"800"},
  reasonBox:{borderTopWidth:1,borderTopColor:colors.border,paddingTop:8,gap:5},
  reason:{color:colors.muted,lineHeight:20},
  note:{color:colors.muted,fontSize:12,lineHeight:18}
});
