
import React, { useState } from "react";
import { SafeAreaView, ScrollView, Text, TextInput, View, StyleSheet } from "react-native";
import { colors } from "../theme";
import PrimaryButton from "../components/PrimaryButton";
import { useAuth } from "../context/AuthContext";

export default function AuthScreen() {
  const { signIn, signUp, cloudConfigured } = useAuth();
  const [mode, setMode] = useState("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit() {
    setBusy(true);
    setMessage("");
    try {
      if (mode === "signin") {
        await signIn(email.trim(), password);
      } else {
        await signUp(email.trim(), password);
        setMessage("Konto opprettet. Sjekk e-post dersom bekreftelse er aktivert.");
      }
    } catch (e) {
      setMessage(e?.message || "Noe gikk galt.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.brand}>HiFi-<Text style={styles.gold}>Match</Text></Text>
        <Text style={styles.title}>{mode === "signin" ? "Logg inn" : "Opprett konto"}</Text>
        <Text style={styles.sub}>
          {cloudConfigured
            ? "Kontoen gjør det mulig å synkronisere anleggene dine mellom enheter."
            : "Skytilkoblingen er klargjort, men Supabase-nøkler må legges inn før innlogging kan brukes."}
        </Text>

        <View style={styles.card}>
          <Text style={styles.label}>E-post</Text>
          <TextInput
            autoCapitalize="none"
            keyboardType="email-address"
            value={email}
            onChangeText={setEmail}
            placeholder="navn@epost.no"
            placeholderTextColor={colors.muted}
            style={styles.input}
          />

          <Text style={styles.label}>Passord</Text>
          <TextInput
            secureTextEntry
            value={password}
            onChangeText={setPassword}
            placeholder="Minst 6 tegn"
            placeholderTextColor={colors.muted}
            style={styles.input}
          />

          {message ? <Text style={styles.message}>{message}</Text> : null}

          <PrimaryButton
            title={busy ? "Arbeider..." : (mode === "signin" ? "Logg inn" : "Opprett konto")}
            disabled={busy || !email.trim() || password.length < 6 || !cloudConfigured}
            onPress={submit}
          />
          <PrimaryButton
            outline
            title={mode === "signin" ? "Ny bruker? Opprett konto" : "Har du konto? Logg inn"}
            onPress={() => { setMode(mode === "signin" ? "signup" : "signin"); setMessage(""); }}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:colors.bg},
  container:{padding:22,gap:14,justifyContent:"center",minHeight:"100%"},
  brand:{fontSize:34,fontWeight:"900",color:colors.text},
  gold:{color:colors.gold},
  title:{fontSize:29,fontWeight:"900",color:colors.text},
  sub:{color:colors.muted,lineHeight:22},
  card:{backgroundColor:colors.panel,borderColor:colors.border,borderWidth:1,borderRadius:18,padding:18,gap:12},
  label:{color:colors.text,fontWeight:"800"},
  input:{backgroundColor:"#09131b",borderColor:colors.border,borderWidth:1,borderRadius:12,padding:14,color:colors.text},
  message:{color:colors.gold,lineHeight:20}
});
