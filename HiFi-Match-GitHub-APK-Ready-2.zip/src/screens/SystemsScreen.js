
import React from "react";
import { SafeAreaView, ScrollView, View, Text, StyleSheet, Pressable } from "react-native";
import { colors } from "../theme";
import PrimaryButton from "../components/PrimaryButton";
import { useAppData } from "../context/AppDataContext";

export default function SystemsScreen({ navigation }) {
  const { systems } = useAppData();

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.heading}>
          <View style={{flex:1}}>
            <Text style={styles.title}>Mine anlegg</Text>
            <Text style={styles.subtitle}>{systems.length} anlegg registrert</Text>
          </View>
        </View>

        <PrimaryButton title="+ Legg til anlegg" outline onPress={() => navigation.navigate("AddSystem")} />

        {systems.map(system => (
          <Pressable style={styles.card} key={system.id} onPress={() => navigation.navigate("SystemDetails", { id: system.id })}>
            <View style={styles.topRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.name}>{system.name}</Text>
                <Text style={styles.systemTitle}>{system.title}</Text>
              </View>
              <Text style={[styles.score, system.score === 0 && styles.unscored]}>
                {system.score === 0 ? "—" : `${system.score}%`}
              </Text>
            </View>
            <Text style={styles.sound}>{system.sound}</Text>
            <Text style={styles.label}>Komponenter</Text>
            {system.components.slice(0, 5).map((c, i) => <Text style={styles.component} key={i}>• {c}</Text>)}
            {system.components.length > 5 && <Text style={styles.more}>+ {system.components.length - 5} flere</Text>}
          </Pressable>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  container: { padding: 18, gap: 14 },
  heading:{flexDirection:"row",alignItems:"center"},
  title: { color: colors.text, fontSize: 30, fontWeight: "900" },
  subtitle: { color: colors.muted, marginTop:4 },
  card: { backgroundColor: colors.panel, borderWidth: 1, borderColor: colors.border, borderRadius: 18, padding: 18 },
  topRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  name: { color: colors.gold, fontWeight: "800" },
  systemTitle: { color: colors.text, fontSize: 19, fontWeight: "800", marginTop: 4 },
  score: { color: colors.green, fontSize: 34, fontWeight: "900" },
  unscored:{color:colors.muted},
  sound: { color: colors.muted, marginVertical: 12, lineHeight: 20 },
  label: { color: colors.text, fontWeight: "800", marginBottom: 6 },
  component: { color: colors.muted, lineHeight: 21 },
  more:{color:colors.gold,marginTop:5,fontWeight:"700"}
});
