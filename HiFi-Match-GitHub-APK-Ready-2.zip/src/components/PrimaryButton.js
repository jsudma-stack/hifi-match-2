
import React from "react";
import { Pressable, Text, StyleSheet } from "react-native";
import { colors } from "../theme";

export default function PrimaryButton({ title, onPress, outline = false, disabled = false }) {
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        styles.button,
        outline && styles.outline,
        disabled && styles.disabled,
        pressed && !disabled && { opacity: 0.85 }
      ]}
    >
      <Text style={[styles.text, outline && styles.outlineText]}>{title}</Text>
    </Pressable>
  );
}
const styles = StyleSheet.create({
  button: {
    backgroundColor: colors.gold,
    borderWidth: 1,
    borderColor: colors.gold,
    borderRadius: 14,
    paddingVertical: 15,
    paddingHorizontal: 18,
    alignItems: "center"
  },
  outline: { backgroundColor: "transparent" },
  disabled: { opacity: 0.35 },
  text: { color: "#111", fontSize: 16, fontWeight: "800" },
  outlineText: { color: colors.gold }
});
