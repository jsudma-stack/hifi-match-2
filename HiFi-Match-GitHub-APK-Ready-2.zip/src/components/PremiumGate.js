
import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { colors } from "../theme";
import PrimaryButton from "./PrimaryButton";

export default function PremiumGate({ title, text, navigation }) {
  return (
    <View style={styles.box}>
      <Text style={styles.badge}>PREMIUM</Text>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.text}>{text}</Text>
      <PrimaryButton title="Se Premium" onPress={() => navigation.navigate("Premium")} />
    </View>
  );
}
const styles = StyleSheet.create({
  box:{backgroundColor:colors.panel2,borderColor:colors.gold,borderWidth:1,borderRadius:18,padding:18,gap:10},
  badge:{color:colors.gold,fontWeight:"900",fontSize:12,letterSpacing:1},
  title:{color:colors.text,fontSize:20,fontWeight:"900"},
  text:{color:colors.muted,lineHeight:21}
});
