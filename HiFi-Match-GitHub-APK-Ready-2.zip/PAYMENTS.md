# Betalingsintegrasjon – produksjonsplan

HiFi-Match v0.5 har en fungerende Premium-flyt i beta, men testbryteren tar ikke betalt.

For produksjon:
1. Opprett abonnementet i App Store Connect og Google Play Console.
2. Bruk butikkens in-app purchase/subscription-system for digitale Premium-funksjoner.
3. Koble appen til et abonnementssystem, for eksempel RevenueCat, eller implementer StoreKit/Google Play Billing direkte.
4. Bruk én entitlement, foreslått navn: `premium`.
5. Foreslåtte produkt-ID-er:
   - `hifimatch_premium_monthly`
   - `hifimatch_premium_yearly`
6. Legg inn "Gjenopprett kjøp".
7. Test i Apple/Google sandbox før lansering.
8. Ikke hardkod faktisk pris i appen; hent den fra butikkproduktet.

Betaversjonen bruker kun lokal teststatus slik at resten av appen kan utvikles og testes uten økonomiske transaksjoner.
