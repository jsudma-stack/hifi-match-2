# HiFi-Match Beta – foreløpig butikktekst

## Kort beskrivelse
Finn HiFi-komponenter som passer sammen – enkelt forklart.

## Beskrivelse
HiFi-Match er laget for både førstegangskjøpere og HiFi-entusiaster.

Bygg ditt eget anlegg, se hvordan komponentene passer sammen, og få en Match-score med en forståelig forklaring. Førstegangsguiden hjelper deg å velge ut fra budsjett, rom, musikk og hvordan du lytter.

Beta-versjonen inneholder:
- Mitt første HiFi-anlegg
- Mine anlegg
- HiFi-database
- Match Engine Beta
- analyse av forsterker og høyttaler
- analyse av pickup og RIAA
- Premium-testfunksjoner

HiFi-Match Beta er under utvikling. Produktdata og vurderinger skal kvalitetssikres videre før offentlig lansering.
