# Personvernerklæring – HiFi-Match Beta

Sist oppdatert: 15. august 2026

HiFi-Match er under betatesting. I lokal betamodus lagres brukerprofil og registrerte HiFi-anlegg på brukerens enhet.

Når konto- og skylagring aktiveres, vil personopplysninger som e-postadresse og brukerens lagrede anlegg kunne behandles for å levere synkronisering og kontofunksjoner. Før offentlig lansering skal denne erklæringen oppdateres med endelig behandlingsansvarlig, kontaktinformasjon, leverandører, lagringstid, rettslig grunnlag, brukerrettigheter og rutiner for sletting.

HiFi-Match skal ikke selge brukernes personopplysninger.

© 2026 Jørn Sudmann. Alle rettigheter forbeholdt.
