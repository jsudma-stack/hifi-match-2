# Produktdata – verifiseringsstatus v0.8

Første verifiseringsrunde er gjennomført for produkter der vi fant produsent- eller manualdata.

## Verifisert
- Electrocompaniet ECI 5: 2 × 120 W i 8 ohm, >80 A peak current, stabil ned til 0,5 ohm.
- Electrocompaniet ECI 3: 2 × 70 W / 8 ohm, 2 × 120 W / 4 ohm, 2 × 160 W / 2 ohm, >60 A peak current, stabil ned til 0,5 ohm.
- Audio Note AZ-Two: 6 ohm, 93 dB, minimum 7 W, maksimum 120 W unclipped, 8" papirkonus bassdriver.
- Pro-Ject Tube Box S2: MM/MC, gain 40/43/50/60/63 dB og flere lastinnstillinger.
- Goldring Elite: MC, 0,5 mV, 1,7 g sporingskraft; 100 ohm er dokumentert som lastreferanse.

## Fortsatt uverifisert i appkatalogen
Blant annet KEF XQ40, AW100 DMB, Sonus Faber Toy Tower, ECD 1, ECP 1, AT33E og flere kilder/platespillere.

Matchmotoren viser nå en egen datakonfidens slik at en høy Match-score ikke skjuler svakt datagrunnlag.

## Verifiseringsrunde 2
- KEF XQ40: 8 ohm nominelt, minimum 3,2 ohm, 90 dB, 15–200 W, 45 Hz–55 kHz.
- Electrocompaniet AW100 DMB: 100 W/8 ohm, 200 W/4 ohm, 350 W/2 ohm, >80 A peak current.
- Sonus Faber Toy Tower: 8 ohm nominelt, 89 dB, 35–200 W, 45 Hz–25 kHz. Uavhengig måling viser minimum rundt 4,2 ohm.
- Electrocompaniet ECP 1: MM/MC, ca. 38,4 dB MM-gain og ca. 73 dB MC-gain.

Audio-Technica AT33EV er nå modellspesifikt verifisert mot Audio-Technicas originale datablad.

## Korrigering – Audio-Technica AT33EV
Pickupen i Anlegg 2 er AT33EV, ikke AT33E.
Verifiserte data: MC, 15–50 000 Hz, 0,3 mV, 10 ohm spoleimpedans, anbefalt last over 100 ohm, 1,8–2,2 g nåletrykk (2,0 g standard), elliptisk 0,3 × 0,7 mil og vekt 6,9 g.
