# Betavilkår – HiFi-Match

HiFi-Match Beta er en testversjon. Funksjoner, produktdata og Match-score kan endres.

Match-score er ment som hjelp til å sammenligne HiFi-komponenter og er ikke en garanti for lydkvalitet, teknisk kompatibilitet eller kjøpsresultat. Brukeren bør kontrollere produsentens spesifikasjoner før tilkobling eller kjøp.

Premium i betaversjonen er kun en testfunksjon og foretar ingen økonomiske transaksjoner.

© 2026 Jørn Sudmann. Alle rettigheter forbeholdt.
