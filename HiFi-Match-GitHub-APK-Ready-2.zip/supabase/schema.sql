
-- HiFi-Match v0.4 beta schema for Supabase
create extension if not exists "pgcrypto";

create table if not exists public.systems (
  id text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  title text not null default '',
  score integer not null default 0 check (score between 0 and 100),
  sound text not null default '',
  components jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.systems enable row level security;

drop policy if exists "Users can read own systems" on public.systems;
create policy "Users can read own systems"
on public.systems for select
using (auth.uid() = user_id);

drop policy if exists "Users can insert own systems" on public.systems;
create policy "Users can insert own systems"
on public.systems for insert
with check (auth.uid() = user_id);

drop policy if exists "Users can update own systems" on public.systems;
create policy "Users can update own systems"
on public.systems for update
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "Users can delete own systems" on public.systems;
create policy "Users can delete own systems"
on public.systems for delete
using (auth.uid() = user_id);
