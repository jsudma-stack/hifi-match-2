START HER: åpne RUN_APK_BUILD.md etter at du har pakket ut filene.
