# HiFi-Match Engine v2

Regelbasert og forklarbar matchmotor.

## Scoreområder
- Teknisk kompatibilitet
- Lydkarakter
- Nivåmatching
- Forsterker/høyttaler
- Pickup/RIAA

## Viktig
Produktkatalogen i v0.6 inneholder enkelte demo-/estimatverdier. De må verifiseres mot produsentdata eller pålitelige kilder før offentlig lansering.

## Videre utvikling
- verifiserte impedanskurver og følsomhet
- strømkapasitet/dempningsfaktor
- romstørrelse og lytteavstand
- gain/loading for pickup og RIAA
- brukerpreferanser
- bruktpris og budsjett
- confidence score på datakvalitet
