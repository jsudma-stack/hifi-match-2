# Lag HiFi-Match APK på GitHub

Du trenger ikke Android Studio.

1. Gå til GitHub og lag et nytt repository med navnet `hifi-match`.
2. Pakk ut ZIP-filen du fikk fra ChatGPT.
3. Last opp **alle filene og mappene** til repositoryet. Det er viktig at `.github/workflows/build-apk.yml` også kommer med.
4. Åpne fanen **Actions** i GitHub.
5. Velg **Build Android APK**.
6. Trykk **Run workflow**.
7. Når jobben er grønn, åpne den ferdige kjøringen.
8. Nederst under **Artifacts** trykker du **HiFi-Match-Beta**.
9. Pakk ut den nedlastede ZIP-en.
10. Der ligger `HiFi-Match-Beta.apk`.
11. Send APK-en til Android-telefonen og trykk på filen for å installere.

## Hvis Android blokkerer installasjonen
På Samsung kan du bli bedt om å tillate installasjon fra nettleseren eller filbehandleren du bruker. Tillat kun dette for appen du bruker til å åpne APK-filen, og installer bare APK-en du selv har bygget.

## Viktig
Dette er en **debug/beta APK** for testing. Den er ikke en ferdig Google Play-produksjonsbuild.
