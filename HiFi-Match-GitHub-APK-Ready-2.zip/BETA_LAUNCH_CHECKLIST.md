# HiFi-Match – Beta Launch Checklist

## Må være ferdig før eksterne betatestere
- [x] Appen er tydelig merket Beta
- [x] Rettighetsmerking i app/prosjekt
- [x] Lokal brukerprofil
- [x] Legg til eget anlegg
- [x] Førstegangsguide
- [x] Match Engine Beta
- [x] Premium-test uten ekte betaling
- [x] Beta personverntekst
- [x] Beta brukervilkår
- [ ] Verifisere alle tekniske produktdata
- [ ] Aktivere og teste Supabase-prosjekt
- [ ] Teste opprett konto / innlogging / utlogging
- [ ] Teste synkronisering mellom to enheter
- [ ] Teste Android fysisk enhet
- [ ] Teste iPhone fysisk enhet
- [ ] Feillogging/crash-rapportering
- [ ] Appikon og splash screen
- [ ] Endelig personvernerklæring med kontaktinfo
- [ ] Supportkontakt
- [ ] Distribusjon via Google Play intern testing
- [ ] Distribusjon via Apple TestFlight

## Før offentlig betalt lansering
- [ ] Verifisert produktdatabase
- [ ] App Store / Google Play utviklerkontoer
- [ ] Opprette Premium-produkter i butikkene
- [ ] Implementere ekte kjøp
- [ ] Gjenopprett kjøp
- [ ] Teste kjøp i sandbox
- [ ] Endelig butikktekst og skjermbilder
- [ ] Slett konto-flyt
- [ ] Produksjonsgjennomgang av personvern og vilkår
