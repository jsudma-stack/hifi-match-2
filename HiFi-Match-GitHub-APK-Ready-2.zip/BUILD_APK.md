# Lag installerbar HiFi-Match APK

## Enkleste metode – GitHub Actions
1. Opprett en gratis GitHub-konto hvis du ikke har en.
2. Opprett et nytt privat repository, for eksempel `hifi-match`.
3. Last opp alle filene fra dette prosjektet.
4. Åpne fanen **Actions**.
5. Velg **Build HiFi-Match Android APK**.
6. Trykk **Run workflow**.
7. Når bygget er grønt, åpne build-resultatet og last ned artifactet **HiFi-Match-Beta-APK**.
8. Pakk ut ZIP-filen og installer `HiFi-Match-Beta.apk` på Android-telefonen.

Android kan be om tillatelse til å installere apper fra nettleseren eller filbehandleren. Dette er en test-APK, ikke en Google Play-versjon.

## Alternativ – Expo EAS
Prosjektet inneholder også `eas.json`. Etter Expo-innlogging kan en APK bygges med:

```bash
npm install
npx eas-cli login
npx eas-cli build --platform android --profile preview
```

## Viktig
Dette lager en testversjon for installasjon på Android. Før offentlig lansering må produksjonsbygg, butikk-signering, personvern, abonnement og butikkoppsett ferdigstilles.
